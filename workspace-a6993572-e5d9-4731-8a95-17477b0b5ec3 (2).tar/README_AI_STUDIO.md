# AI Studio - Text to Video (4K) & Image Generation

## 🚀 Quick Start

AI Studio is now live! Visit the application to start generating 4K videos and realistic images from text.

**Access the app at the root URL**

## ✨ What Can You Do?

### 🎬 Generate 4K Videos
- Transform text into stunning 4K quality videos
- Choose from multiple resolutions (4K, Full HD, HD)
- Customize duration (5 or 10 seconds)
- Select frame rate (30 or 60 FPS)
- Add AI-generated audio
- Download in MP4 format

### 🖼️ Generate Realistic Images
- Create photorealistic images from text
- Choose from 7 aspect ratios
- Perfect for social media, websites, and print
- Download in PNG format

## 📖 Documentation

- **📚 User Guide**: See `AI_STUDIO_GUIDE.md` for detailed instructions
- **📊 Project Summary**: See `AI_STUDIO_SUMMARY.md` for technical details

## 🎯 Example Uses

### Video Generation
```
Prompt: "A majestic eagle soaring over snow-capped mountains at golden hour, cinematic lighting"
Settings: 4K UHD, 10 seconds, 60 FPS, Quality mode
```

### Image Generation
```
Prompt: "Professional product photography of wireless headphones, white background, studio lighting, 8K"
Settings: 1344x768 (Landscape)
```

## 🛠️ Tech Stack

- **Frontend**: Next.js 15, React 19, TypeScript, Tailwind CSS, shadcn/ui
- **Backend**: Next.js API Routes, z-ai-web-dev-sdk
- **AI Models**: State-of-the-art video and image generation

## 📝 Features

### Video Generation
- ✅ 4K UHD (3840x2160) resolution
- ✅ Multiple quality and speed options
- ✅ Custom duration and frame rate
- ✅ AI audio generation
- ✅ Real-time progress tracking
- ✅ Video preview and download

### Image Generation
- ✅ High-quality photorealistic output
- ✅ Multiple aspect ratios
- ✅ Instant generation
- ✅ Image preview and download

### User Interface
- ✅ Modern dark theme
- ✅ Tab-based navigation
- ✅ Generation history
- ✅ Responsive design
- ✅ Error handling and notifications

## 🔑 API Endpoints

### Video Generation
**POST** `/api/generate/video`

Request:
```json
{
  "prompt": "your video description",
  "quality": "quality" | "speed",
  "duration": 5 | 10,
  "fps": 30 | 60,
  "size": "3840x2160",
  "with_audio": boolean
}
```

Response:
```json
{
  "success": true,
  "taskId": "task-id",
  "videoUrl": "https://...",
  "pollAttempts": number
}
```

### Image Generation
**POST** `/api/generate/image`

Request:
```json
{
  "prompt": "your image description",
  "size": "1344x768"
}
```

Response:
```json
{
  "success": true,
  "imageUrl": "/generated-images/...",
  "prompt": "...",
  "size": "1344x768"
}
```

## 💡 Tips for Best Results

### Videos
- Be descriptive about scenes, actions, lighting
- Include camera movements and style
- Use Quality mode for important projects
- Enable audio for enhanced experience

### Images
- Be specific about subject, style, details
- Include quality terms (photorealistic, 8K)
- Choose appropriate aspect ratio for your use case

## ⚙️ Supported Settings

### Video Resolutions
- 3840x2160 (4K UHD)
- 1920x1080 (Full HD)
- 1440x720 (HD Wide)
- 1344x768 (Landscape)

### Image Sizes
- 1024x1024 (Square)
- 1344x768, 1152x864, 1440x720 (Landscape)
- 768x1344, 864x1152, 720x1440 (Portrait)

## 🎨 Design Features

- Dark gradient theme (slate to purple)
- Purple accent for video generation
- Pink accent for image generation
- Responsive layout (mobile & desktop)
- Modern shadcn/ui components
- Lucide icons
- Toast notifications
- Scroll areas for content

## 📊 Performance

- **Video Generation**: 1-4 minutes depending on settings
- **Image Generation**: 5-15 seconds
- **Speed Mode**: Faster, slightly lower quality
- **Quality Mode**: Better quality, longer time

## 🔐 Notes

- Generated images are stored temporarily in public/generated-images/
- Download videos and images to save permanently
- No personal data is stored
- All processing happens on secure backend servers

## 🚦 License

MIT License - Free to use and modify

## 📞 Support

For detailed usage instructions, refer to `AI_STUDIO_GUIDE.md`

---

**Ready to create amazing content! 🎉**
