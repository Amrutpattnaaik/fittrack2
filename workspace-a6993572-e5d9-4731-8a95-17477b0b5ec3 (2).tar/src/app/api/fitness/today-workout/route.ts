import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const today = new Date()
    today.setHours(0, 0, 0, 0)

    const tomorrow = new Date(today)
    tomorrow.setDate(tomorrow.getDate() + 1)

    const workoutPlan = await db.workoutPlan.findFirst({
      where: {
        date: {
          gte: today,
          lt: tomorrow,
        }
      },
      orderBy: { date: 'desc' }
    })

    if (!workoutPlan) {
      return NextResponse.json(null, { status: 404 })
    }

    return NextResponse.json(workoutPlan)
  } catch (error) {
    console.error('Error fetching today workout:', error)
    return NextResponse.json(
      { error: 'Failed to fetch today workout' },
      { status: 500 }
    )
  }
}
