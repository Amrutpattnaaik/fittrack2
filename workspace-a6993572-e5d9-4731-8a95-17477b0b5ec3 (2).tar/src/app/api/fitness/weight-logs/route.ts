import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const weightLogs = await db.weightLog.findMany({
      orderBy: { date: 'desc' },
      take: 50
    })

    return NextResponse.json(weightLogs)
  } catch (error) {
    console.error('Error fetching weight logs:', error)
    return NextResponse.json(
      { error: 'Failed to fetch weight logs' },
      { status: 500 }
    )
  }
}
