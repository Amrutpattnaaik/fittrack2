import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const weightLogs = await db.weightLog.findMany({
      orderBy: { date: 'desc' },
      take: 50
    })

    return NextResponse.json(weightLogs)
  } catch (error) {
    console.error('Error fetching weight logs:', error)
    return NextResponse.json(
      { error: 'Failed to fetch weight logs' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { weight, note } = body

    if (!weight) {
      return NextResponse.json(
        { error: 'Weight is required' },
        { status: 400 }
      )
    }

    const weightLog = await db.weightLog.create({
      data: {
        weight,
        note,
      }
    })

    return NextResponse.json(weightLog)
  } catch (error) {
    console.error('Error logging weight:', error)
    return NextResponse.json(
      { error: 'Failed to log weight' },
      { status: 500 }
    )
  }
}
