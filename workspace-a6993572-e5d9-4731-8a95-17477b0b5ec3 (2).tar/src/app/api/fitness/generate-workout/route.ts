import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import ZAI from 'z-ai-web-dev-sdk'

export async function POST(request: NextRequest) {
  try {
    const profile = await db.fitnessProfile.findFirst({
      orderBy: { updatedAt: 'desc' }
    })

    if (!profile) {
      return NextResponse.json(
        { error: 'No fitness profile found' },
        { status: 404 }
      )
    }

    const systemPrompt = `You are a professional fitness trainer. Generate personalized workout plans based on user's profile.
Focus on safe, effective exercises suitable for their fitness level and goals.
Return the response as a JSON array of exercises, each with name, description, sets, reps, and duration (in minutes).`

    const userPrompt = `Create a workout plan for someone with the following profile:
- Weight: ${profile.weight} kg
- Height: ${profile.height} cm
- Age: ${profile.age} years old
- Activity Level: ${profile.activityLevel}
- Fitness Goal: ${profile.goal}

Generate 5-6 exercises that are appropriate for this person. For each exercise include:
- name: exercise name
- description: brief description of how to perform it
- sets: number of sets
- reps: number of reps
- duration: estimated duration in minutes

Return ONLY a JSON array, no other text or explanation.`

    const zai = await ZAI.create()

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'assistant',
          content: systemPrompt
        },
        {
          role: 'user',
          content: userPrompt
        }
      ],
      thinking: { type: 'disabled' }
    })

    const responseText = completion.choices[0]?.message?.content || '[]'

    let exercises
    try {
      exercises = JSON.parse(responseText)
    } catch (e) {
      // Try wrapping in array if it's not already
      try {
        exercises = JSON.parse(`[${responseText}]`)
      } catch (e2) {
        // Fallback to default exercises if parsing fails
        exercises = [
          {
            name: 'Bodyweight Squats',
            description: 'Stand with feet shoulder-width apart. Lower your body as if sitting in a chair, then return to standing.',
            sets: 3,
            reps: 15,
            duration: 5
          },
          {
            name: 'Push-ups',
            description: 'Start in plank position. Lower body until chest nearly touches floor, then push back up.',
            sets: 3,
            reps: 10,
            duration: 5
          },
          {
            name: 'Lunges',
            description: 'Step forward with one leg, lowering hips until both knees are bent at 90 degrees, then return to standing.',
            sets: 3,
            reps: 12,
            duration: 5
          },
          {
            name: 'Plank',
            description: 'Hold a plank position with forearms on ground, body straight from head to heels.',
            sets: 3,
            reps: 1,
            duration: 5
          },
          {
            name: 'Jumping Jacks',
            description: 'Jump while spreading legs and raising arms overhead, then return to starting position.',
            sets: 3,
            reps: 20,
            duration: 3
          }
        ]
      }
    }

    const totalDuration = exercises.reduce((sum: number, ex: any) => sum + (ex.duration || 5), 0)

    const caloriesPerMin = profile.activityLevel === 'sedentary' ? 5 :
                         profile.activityLevel === 'light' ? 6 :
                         profile.activityLevel === 'moderate' ? 7 :
                         profile.activityLevel === 'active' ? 8 : 10

    const totalCalories = Math.round(totalDuration * caloriesPerMin)

    const workoutPlan = await db.workoutPlan.create({
      data: {
        exercises: JSON.stringify(exercises),
        calories: totalCalories,
        duration: totalDuration,
        date: new Date(),
      }
    })

    return NextResponse.json(workoutPlan)
  } catch (error) {
    console.error('Error generating workout:', error)
    return NextResponse.json(
      { error: 'Failed to generate workout plan' },
      { status: 500 }
    )
  }
}
