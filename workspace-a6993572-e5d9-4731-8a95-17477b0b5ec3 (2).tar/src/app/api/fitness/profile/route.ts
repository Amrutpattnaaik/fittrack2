import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const profile = await db.fitnessProfile.findFirst({
      orderBy: { updatedAt: 'desc' }
    })

    if (!profile) {
      return NextResponse.json(null, { status: 404 })
    }

    return NextResponse.json(profile)
  } catch (error) {
    console.error('Error fetching fitness profile:', error)
    return NextResponse.json(
      { error: 'Failed to fetch fitness profile' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { weight, height, age, goal, activityLevel } = body

    if (!weight || !height || !age || !goal || !activityLevel) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    const existingProfile = await db.fitnessProfile.findFirst()

    let profile
    if (existingProfile) {
      profile = await db.fitnessProfile.update({
        where: { id: existingProfile.id },
        data: {
          weight,
          height,
          age,
          goal,
          activityLevel,
        }
      })
    } else {
      profile = await db.fitnessProfile.create({
        data: {
          weight,
          height,
          age,
          goal,
          activityLevel,
        }
      })
    }

    return NextResponse.json(profile)
  } catch (error) {
    console.error('Error saving fitness profile:', error)
    return NextResponse.json(
      { error: 'Failed to save fitness profile' },
      { status: 500 }
    )
  }
}
