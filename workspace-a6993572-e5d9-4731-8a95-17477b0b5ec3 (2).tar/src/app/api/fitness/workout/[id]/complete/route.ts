import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const workoutId = params.id

    const workoutPlan = await db.workoutPlan.update({
      where: { id: workoutId },
      data: { completed: true }
    })

    return NextResponse.json(workoutPlan)
  } catch (error) {
    console.error('Error completing workout:', error)
    return NextResponse.json(
      { error: 'Failed to complete workout' },
      { status: 500 }
    )
  }
}
