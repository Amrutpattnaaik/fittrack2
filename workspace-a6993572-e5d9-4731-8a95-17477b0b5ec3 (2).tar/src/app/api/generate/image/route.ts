import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'
import { writeFile, mkdir } from 'fs/promises'
import { join } from 'path'

export async function POST(request: NextRequest) {
  try {
    // Read request body properly
    const text = await request.text()
    let body: any

    try {
      body = JSON.parse(text)
    } catch (e) {
      return NextResponse.json(
        { error: 'Invalid JSON in request body' },
        { status: 400 }
      )
    }

    const { prompt, size = '1344x768' } = body

    if (!prompt || typeof prompt !== 'string') {
      return NextResponse.json(
        { error: 'Prompt is required and must be a string' },
        { status: 400 }
      )
    }

    const zai = await ZAI.create()

    // Generate image
    const response = await zai.images.generations.create({
      prompt: prompt,
      size: size
    })

    if (!response.data || !response.data[0] || !response.data[0].base64) {
      return NextResponse.json(
        { error: 'Invalid response from image generation API' },
        { status: 500 }
      )
    }

    const imageBase64 = response.data[0].base64

    // Create output directory if it doesn't exist
    const outputDir = join(process.cwd(), 'public', 'generated-images')
    try {
      await mkdir(outputDir, { recursive: true })
    } catch (err) {
      // Directory might already exist, ignore error
    }

    // Save image to public folder
    const filename = `img_${Date.now()}.png`
    const imagePath = join(outputDir, filename)
    const buffer = Buffer.from(imageBase64, 'base64')
    await writeFile(imagePath, buffer)

    console.log('Image saved to:', imagePath)

    // Return URL to access to image
    const imageUrl = `/generated-images/${filename}`

    return NextResponse.json({
      success: true,
      imageUrl: imageUrl,
      prompt: prompt,
      size: size
    })
  } catch (error: any) {
    console.error('Error generating image:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to generate image' },
      { status: 500 }
    )
  }
}
