import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export async function POST(request: NextRequest) {
  try {
    // Read request body properly
    const text = await request.text()
    let body: any

    try {
      body = JSON.parse(text)
    } catch (e) {
      return NextResponse.json(
        { error: 'Invalid JSON in request body' },
        { status: 400 }
      )
    }

    const { prompt, quality = 'quality', duration = 5, fps = 30, size = '1920x1080', with_audio = false } = body

    if (!prompt || typeof prompt !== 'string') {
      return NextResponse.json(
        { error: 'Prompt is required and must be a string' },
        { status: 400 }
      )
    }

    const zai = await ZAI.create()

    // Create video generation task
    const task = await zai.video.generations.create({
      prompt: prompt,
      quality: quality as 'speed' | 'quality',
      duration: duration as 5 | 10,
      fps: fps as 30 | 60,
      size: size,
      with_audio: with_audio
    })

    console.log('Video task created:', task.id, task.task_status)

    // Poll for results
    let result = await zai.async.result.query(task.id)
    let pollCount = 0
    const maxPolls = 60
    const pollInterval = 5000

    while (result.task_status === 'PROCESSING' && pollCount < maxPolls) {
      pollCount++
      console.log(`Video polling ${pollCount}/${maxPolls}: Status is ${result.task_status}`)
      await new Promise(resolve => setTimeout(resolve, pollInterval))
      result = await zai.async.result.query(task.id)
    }

    if (result.task_status === 'SUCCESS') {
      // Get video URL from multiple possible fields
      const videoUrl = result.video_result?.[0]?.url ||
                      result.video_url ||
                      result.url ||
                      result.video

      if (videoUrl) {
        console.log('Video generated successfully:', videoUrl)
        return NextResponse.json({
          success: true,
          taskId: task.id,
          videoUrl: videoUrl,
          pollAttempts: pollCount
        })
      } else {
        return NextResponse.json(
          { error: 'Video generation completed but no URL returned' },
          { status: 500 }
        )
      }
    } else if (result.task_status === 'FAIL') {
      console.error('Video generation failed')
      return NextResponse.json(
        { error: 'Video generation failed' },
        { status: 500 }
      )
    } else {
      console.error('Video generation timeout')
      return NextResponse.json(
        { error: 'Video generation timed out after 5 minutes' },
        { status: 408 }
      )
    }
  } catch (error: any) {
    console.error('Error generating video:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to generate video' },
      { status: 500 }
    )
  }
}
