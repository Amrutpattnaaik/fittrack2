'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { toast } from '@/hooks/use-toast'
import {
  Activity,
  Calendar,
  Clock,
  Flame,
  TrendingUp,
  Bell,
  Target,
  CheckCircle2,
  Dumbbell,
  Heart,
  Scale,
  Ruler,
  Settings,
  Palette,
  Save,
} from 'lucide-react'

export default function Home() {
  const [activeTab, setActiveTab] = useState('dashboard')
  const [profile, setProfile] = useState(null)
  const [workoutPlan, setWorkoutPlan] = useState(null)
  const [weightLogs, setWeightLogs] = useState([])
  const [notificationEnabled, setNotificationEnabled] = useState(false)
  const [loading, setLoading] = useState(false)
  const [settingsDialogOpen, setSettingsDialogOpen] = useState(false)
  const [settings, setSettings] = useState({
    appName: 'FitTrack AI',
    tagline: 'Your Personal Fitness Companion',
    primaryColor: 'purple',
    footerText: 'Stay healthy, stay active!',
  })

  useEffect(() => {
    loadProfile()
    loadTodayWorkout()
    loadWeightLogs()
  }, [])

  const loadProfile = async () => {
    try {
      const response = await fetch('/api/fitness/profile')
      if (response.ok) {
        const data = await response.json()
        setProfile(data)
      }
    } catch (error) {
      console.error('Failed to load profile:', error)
    }
  }

  const loadTodayWorkout = async () => {
    try {
      const response = await fetch('/api/fitness/today-workout')
      if (response.ok) {
        const data = await response.json()
        setWorkoutPlan(data)
      }
    } catch (error) {
      console.error('Failed to load workout:', error)
    }
  }

  const loadWeightLogs = async () => {
    try {
      const response = await fetch('/api/fitness/weight-logs')
      if (response.ok) {
        const data = await response.json()
        setWeightLogs(data)
      }
    } catch (error) {
      console.error('Failed to load weight logs:', error)
    }
  }

  const generateWorkout = async () => {
    if (!profile) {
      toast({
        title: 'Profile Required',
        description: 'Please complete your fitness profile first',
        variant: 'destructive',
      })
      return
    }

    setLoading(true)
    try {
      const response = await fetch('/api/fitness/generate-workout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      })

      if (response.ok) {
        await loadTodayWorkout()
        toast({
          title: 'Workout Generated',
          description: 'Your personalized workout is ready!',
        })
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to generate workout',
        variant: 'destructive',
      })
    } finally {
      setLoading(false)
    }
  }

  const completeWorkout = async () => {
    if (!workoutPlan) return

    setLoading(true)
    try {
      const response = await fetch('/api/fitness/workout/' + workoutPlan.id + '/complete', {
        method: 'POST',
      })

      if (response.ok) {
        await loadTodayWorkout()
        toast({
          title: 'Workout Completed',
          description: 'Great job! Keep up the good work!',
        })
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to complete workout',
        variant: 'destructive',
      })
    } finally {
      setLoading(false)
    }
  }

  const saveProfile = async (e) => {
    e.preventDefault()
    setLoading(true)
    const formData = new FormData(e.currentTarget)

    try {
      const response = await fetch('/api/fitness/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          weight: parseFloat(formData.get('weight')),
          height: parseFloat(formData.get('height')),
          age: parseInt(formData.get('age')),
          goal: formData.get('goal'),
          activityLevel: formData.get('activityLevel'),
        }),
      })

      if (response.ok) {
        await loadProfile()
        toast({
          title: 'Profile Saved',
          description: 'Your fitness profile has been updated!',
        })
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to save profile',
        variant: 'destructive',
      })
    } finally {
      setLoading(false)
    }
  }

  const logWeight = async (e) => {
    e.preventDefault()
    setLoading(true)
    const formData = new FormData(e.currentTarget)

    try {
      const response = await fetch('/api/fitness/weight-log', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          weight: parseFloat(formData.get('weight')),
          note: formData.get('note'),
        }),
      })

      if (response.ok) {
        await loadWeightLogs()
        e.currentTarget.reset()
        toast({
          title: 'Weight Logged',
          description: 'Your weight has been recorded!',
        })
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to log weight',
        variant: 'destructive',
      })
    } finally {
      setLoading(false)
    }
  }

  const parseExercises = (exercisesString) => {
    try {
      return JSON.parse(exercisesString)
    } catch {
      return []
    }
  }

  const getColorClasses = () => {
    const colorMap = {
      purple: { primary: 'text-purple-500', primaryBg: 'bg-purple-600', primaryGradient: 'from-purple-400 via-purple-600 to-pink-500', secondary: 'text-pink-500', secondaryBg: 'bg-pink-500/20', border: 'border-purple-500/30' },
      blue: { primary: 'text-blue-500', primaryBg: 'bg-blue-600', primaryGradient: 'from-blue-400 via-blue-600 to-cyan-500', secondary: 'text-cyan-500', secondaryBg: 'bg-cyan-500/20', border: 'border-blue-500/30' },
      green: { primary: 'text-green-500', primaryBg: 'bg-green-600', primaryGradient: 'from-green-400 via-green-600 to-emerald-500', secondary: 'text-emerald-500', secondaryBg: 'bg-emerald-500/20', border: 'border-green-500/30' },
      orange: { primary: 'text-orange-500', primaryBg: 'bg-orange-600', primaryGradient: 'from-orange-400 via-orange-600 to-amber-500', secondary: 'text-amber-500', secondaryBg: 'bg-amber-500/20', border: 'border-orange-500/30' },
      red: { primary: 'text-red-500', primaryBg: 'bg-red-600', primaryGradient: 'from-red-400 via-red-600 to-rose-500', secondary: 'text-rose-500', secondaryBg: 'bg-rose-500/20', border: 'border-red-500/30' },
    }

    return colorMap[settings.primaryColor] || colorMap.purple
  }

  const colorClasses = getColorClasses()

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      <div className="container mx-auto px-4 py-8 pb-24">
        <header className="mb-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Activity className={'h-10 w-10 ' + colorClasses.primary} />
              <div>
                <h1 className={'text-4xl font-bold bg-gradient-to-r ' + colorClasses.primaryGradient + ' bg-clip-text text-transparent'}>
                  {settings.appName}
                </h1>
                <p className="text-muted-foreground text-lg">{settings.tagline}</p>
              </div>
            </div>
            
            <Dialog open={settingsDialogOpen} onOpenChange={setSettingsDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" size="icon" className="rounded-full">
                  <Settings className={'h-6 w-6 ' + colorClasses.secondary} />
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <Palette className={'h-6 w-6 ' + colorClasses.primary} />
                    Customize App
                  </DialogTitle>
                  <DialogDescription>
                    Personalize your fitness tracking experience
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-6 py-4">
                  <div className="space-y-3">
                    <Label htmlFor="appName">App Name</Label>
                    <Input
                      id="appName"
                      value={settings.appName}
                      onChange={(e) => setSettings({ ...settings, appName: e.target.value })}
                      placeholder="FitTrack AI"
                    />
                  </div>

                  <div className="space-y-3">
                    <Label htmlFor="tagline">Tagline</Label>
                    <Input
                      id="tagline"
                      value={settings.tagline}
                      onChange={(e) => setSettings({ ...settings, tagline: e.target.value })}
                      placeholder="Your Personal Fitness Companion"
                    />
                  </div>

                  <div className="space-y-3">
                    <Label>Color Scheme</Label>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {['purple', 'blue', 'green', 'orange', 'red'].map((color) => (
                        <Button
                          key={color}
                          variant={settings.primaryColor === color ? 'default' : 'outline'}
                          className={settings.primaryColor === color ? colorClasses.primaryBg : ''}
                          onClick={() => setSettings({ ...settings, primaryColor: color })}
                        >
                          <div className="flex items-center gap-2">
                            <div className={'w-4 h-4 rounded-full bg-' + color + '-500'} />
                            <span className="capitalize">{color}</span>
                          </div>
                        </Button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-3">
                    <Label htmlFor="footerText">Footer Text</Label>
                    <Input
                      id="footerText"
                      value={settings.footerText}
                      onChange={(e) => setSettings({ ...settings, footerText: e.target.value })}
                      placeholder="Stay healthy, stay active!"
                    />
                  </div>

                  <Button onClick={() => localStorage.setItem('appSettings', JSON.stringify(settings))} className="w-full" size="lg">
                    <Save className="mr-2 h-5 w-5" />
                    Save Settings
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </header>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8 bg-slate-900/50 backdrop-blur border border-purple-500/30">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="workout">Workout</TabsTrigger>
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="progress">Progress</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-3">
              {profile && (
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Current Weight</CardTitle>
                    <Scale className={'h-4 w-4 ' + colorClasses.secondary} />
                  </CardHeader>
                  <CardContent>
                    <div className={'text-2xl font-bold ' + colorClasses.primary}>{profile.weight} kg</div>
                    <p className={'text-xs ' + colorClasses.secondary + ' mt-1'}>
                      {profile.goal === 'lose' ? 'Goal: Lose Weight' :
                       profile.goal === 'gain' ? 'Goal: Gain Muscle' : 'Goal: Stay Fit'}
                    </p>
                  </CardContent>
                </Card>
              )}

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Today's Status</CardTitle>
                  <CheckCircle2 className={'h-4 w-4 ' + (workoutPlan?.completed ? 'text-green-500' : colorClasses.secondary)} />
                </CardHeader>
                <CardContent>
                  <div className={'text-2xl font-bold ' + colorClasses.primary}>
                    {workoutPlan?.completed ? 'Completed' : 'Pending'}
                  </div>
                  <p className={'text-xs ' + colorClasses.secondary + ' mt-1'}>
                    {workoutPlan?.completed ? 'All tasks done!' : 'Workout scheduled'}
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Notifications</CardTitle>
                  <Bell className={'h-4 w-4 ' + (notificationEnabled ? 'text-green-500' : colorClasses.secondary)} />
                </CardHeader>
                <CardContent>
                  <div className={'text-2xl font-bold ' + colorClasses.primary}>
                    {notificationEnabled ? 'Active' : 'Disabled'}
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    className="mt-2 w-full"
                    onClick={() => {
                      if ('Notification' in window) {
                        Notification.requestPermission().then((permission) => {
                          setNotificationEnabled(permission === 'granted')
                          if (permission === 'granted') {
                            toast({
                              title: 'Notifications Enabled',
                              description: 'You will receive daily workout reminders!',
                            })
                          }
                        })
                      }
                    }}
                    disabled={notificationEnabled}
                  >
                    {notificationEnabled ? '✓ Enabled' : 'Enable Alerts'}
                  </Button>
                </CardContent>
              </Card>
            </div>

            {workoutPlan && (
              <Card className="shadow-lg">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-2xl">Today's Workout Plan</CardTitle>
                      <CardDescription>AI-generated based on your profile</CardDescription>
                    </div>
                    {!workoutPlan.completed && (
                      <Button
                        onClick={completeWorkout}
                        disabled={loading}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        <CheckCircle2 className="mr-2 h-4 w-4" />
                        Complete Workout
                      </Button>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex gap-4 mb-4">
                    <div className="flex items-center gap-2">
                      <Flame className="h-5 w-5 text-orange-500" />
                      <span className={'font-semibold ' + colorClasses.primary}>{workoutPlan.calories} kcal</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="h-5 w-5 text-blue-500" />
                      <span className={'font-semibold ' + colorClasses.primary}>{workoutPlan.duration} min</span>
                    </div>
                  </div>

                  <ScrollArea className="h-64 pr-4">
                    <div className="space-y-3">
                      {parseExercises(workoutPlan.exercises).map((exercise, idx) => (
                        <Card key={idx} className="bg-muted/50">
                          <CardContent className="pt-4">
                            <div className="flex items-start gap-3">
                              <Dumbbell className={'h-5 w-5 ' + colorClasses.primary + ' mt-1'} />
                              <div className="flex-1">
                                <h4 className="font-semibold">{exercise.name}</h4>
                                <p className="text-sm text-muted-foreground">{exercise.description}</p>
                                <div className="flex gap-2 mt-2">
                                  <Badge variant="secondary">{exercise.sets} sets</Badge>
                                  <Badge variant="secondary">{exercise.reps} reps</Badge>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            )}

            {!workoutPlan && (
              <Card className="shadow-lg">
                <CardContent className="pt-6 text-center py-12">
                  <Dumbbell className={'h-16 w-16 ' + colorClasses.secondary + ' mx-auto mb-4'} />
                  <h3 className={'text-xl font-semibold mb-2 ' + colorClasses.primary}>No Workout Plan Yet</h3>
                  <p className="text-muted-foreground mb-4">
                    Generate your personalized workout plan based on your fitness profile
                  </p>
                  <Button onClick={generateWorkout} disabled={loading || !profile} size="lg">
                    {loading ? 'Generating...' : 'Generate Workout Plan'}
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="workout" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Generate New Workout</CardTitle>
                <CardDescription>
                  Get AI-powered workout recommendations based on your current weight and goals
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button
                  onClick={generateWorkout}
                  disabled={loading || !profile}
                  size="lg"
                  className="w-full"
                >
                  {loading ? (
                    <>Generating...</>
                  ) : (
                    <>
                      <Dumbbell className="mr-2 h-5 w-5" />
                      Generate Personalized Workout
                    </>
                  )}
                </Button>
                {!profile && (
                  <p className="text-sm text-muted-foreground text-center mt-2">
                    Please complete your profile first
                  </p>
                )}
              </CardContent>
            </Card>

            {workoutPlan && (
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Current Workout Plan</CardTitle>
                      <CardDescription>
                        {new Date(workoutPlan.date).toLocaleDateString('en-US', {
                          weekday: 'long',
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric',
                        })}
                      </CardDescription>
                    </div>
                    <Badge className={workoutPlan.completed ? 'bg-green-600' : 'bg-yellow-600'}>
                      {workoutPlan.completed ? 'Completed' : 'In Progress'}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[400px] pr-4">
                    <div className="space-y-4">
                      {parseExercises(workoutPlan.exercises).map((exercise, idx) => (
                        <Card key={idx} className={'bg-gradient-to-br ' + colorClasses.primary + ' to-background'}>
                          <CardContent className="pt-6">
                            <div className="flex items-start gap-4">
                              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                                <Activity className={'h-6 w-6 ' + colorClasses.primary} />
                              </div>
                              <div className="flex-1">
                                <h4 className={'font-semibold text-lg ' + colorClasses.primary}>{exercise.name}</h4>
                                <p className="text-muted-foreground mt-1">{exercise.description}</p>
                                <div className="flex flex-wrap gap-2 mt-3">
                                  <Badge variant="outline" className="text-sm">
                                    {exercise.sets} sets
                                  </Badge>
                                  <Badge variant="outline" className="text-sm">
                                    {exercise.reps} reps
                                  </Badge>
                                  <Badge variant="outline" className="text-sm">
                                    {exercise.duration || 5} min
                                  </Badge>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </ScrollArea>
                  {!workoutPlan.completed && (
                    <Button
                      onClick={completeWorkout}
                      disabled={loading}
                      className="w-full mt-6 bg-green-600 hover:bg-green-700"
                      size="lg"
                    >
                      <CheckCircle2 className="mr-2 h-5 w-5" />
                      Mark Workout as Complete
                    </Button>
                  )}
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="profile" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Fitness Profile</CardTitle>
                <CardDescription>
                  Tell us about yourself to get personalized workout recommendations
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={saveProfile} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="weight" className="flex items-center gap-2">
                        <Scale className="h-4 w-4" />
                        Weight (kg)
                      </Label>
                      <Input
                        id="weight"
                        name="weight"
                        type="number"
                        step="0.1"
                        placeholder="70.5"
                        defaultValue={profile?.weight}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="height" className="flex items-center gap-2">
                        <Ruler className="h-4 w-4" />
                        Height (cm)
                      </Label>
                      <Input
                        id="height"
                        name="height"
                        type="number"
                        placeholder="175"
                        defaultValue={profile?.height}
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="age" className="flex items-center gap-2">
                        <Calendar className="h-4 w-4" />
                        Age
                      </Label>
                      <Input
                        id="age"
                        name="age"
                        type="number"
                        placeholder="25"
                        defaultValue={profile?.age}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="activityLevel" className="flex items-center gap-2">
                        <Activity className="h-4 w-4" />
                        Activity Level
                      </Label>
                      <Select name="activityLevel" defaultValue={profile?.activityLevel} required>
                        <SelectTrigger>
                          <SelectValue placeholder="Select your activity level" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="sedentary">Sedentary (Little to no exercise)</SelectItem>
                          <SelectItem value="light">Light (1-3 days/week)</SelectItem>
                          <SelectItem value="moderate">Moderate (3-5 days/week)</SelectItem>
                          <SelectItem value="active">Active (6-7 days/week)</SelectItem>
                          <SelectItem value="very-active">Very Active (2x per day)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="goal" className="flex items-center gap-2">
                      <Target className="h-4 w-4" />
                      Fitness Goal
                    </Label>
                    <Select name="goal" defaultValue={profile?.goal} required>
                      <SelectTrigger>
                        <SelectValue placeholder="Select your fitness goal" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="lose">Lose Weight</SelectItem>
                        <SelectItem value="gain">Build Muscle</SelectItem>
                        <SelectItem value="maintain">Maintain Weight</SelectItem>
                        <SelectItem value="endurance">Improve Endurance</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Button type="submit" disabled={loading} className="w-full" size="lg">
                    {loading ? 'Saving...' : 'Save Profile'}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="progress" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Log Your Weight</CardTitle>
                <CardDescription>Track your weight changes over time</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={logWeight} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="md:col-span-1 space-y-2">
                      <Label htmlFor="current-weight">Weight (kg)</Label>
                      <Input
                        id="current-weight"
                        name="weight"
                        type="number"
                        step="0.1"
                        placeholder="70.5"
                        required
                      />
                    </div>
                    <div className="md:col-span-2 space-y-2">
                      <Label htmlFor="note">Note (optional)</Label>
                      <Input
                        id="note"
                        name="note"
                        type="text"
                        placeholder="Any notes about today's weigh-in"
                      />
                    </div>
                  </div>
                  <Button type="submit" disabled={loading} className="w-full">
                    {loading ? 'Logging...' : 'Log Weight'}
                  </Button>
                </form>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className={'h-5 w-5 ' + colorClasses.primary} />
                  Weight History
                </CardTitle>
                <CardDescription>Your weight tracking journey</CardDescription>
              </CardHeader>
              <CardContent>
                {weightLogs.length > 0 ? (
                  <ScrollArea className="h-[400px] pr-4">
                    <div className="space-y-3">
                      {weightLogs.map((log) => (
                        <Card key={log.id} className="bg-muted/50">
                          <CardContent className="pt-4">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                                  <Scale className={'h-5 w-5 ' + colorClasses.primary} />
                                </div>
                                <div>
                                  <div className={'font-semibold ' + colorClasses.primary}>{log.weight} kg</div>
                                  <div className={'text-sm ' + colorClasses.secondary}>
                                    {new Date(log.date).toLocaleDateString('en-US', {
                                      weekday: 'short',
                                      month: 'short',
                                      day: 'numeric',
                                    })}
                                  </div>
                                </div>
                              </div>
                              {log.note && (
                                <p className={'text-sm text-muted-foreground text-right max-w-[200px] ' + colorClasses.secondary}>
                                  {log.note}
                                </p>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </ScrollArea>
                ) : (
                  <div className="text-center py-12 text-muted-foreground">
                    <Scale className={'h-12 w-12 ' + colorClasses.secondary + ' mx-auto mb-4 opacity-50'} />
                    <p>No weight logs yet. Start tracking your progress!</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <footer className="fixed bottom-0 left-0 right-0 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-t">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <p className="flex items-center gap-2">
                <Heart className="h-4 w-4 text-red-500" />
                {settings.footerText}
              </p>
              <p className="hidden sm:block">
                {settings.appName} - {settings.tagline}
              </p>
            </div>
          </div>
        </footer>
      </div>
    </div>
  )
}
