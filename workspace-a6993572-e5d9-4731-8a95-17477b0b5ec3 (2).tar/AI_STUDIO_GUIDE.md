# AI Studio - Text to Video & Image Generation

## Overview

AI Studio is a powerful web application that enables users to:
- **Convert text to 4K quality videos** using advanced AI
- **Generate realistic images** from text descriptions
- **Download and manage** all generated content

## Features

### Text to Video
- **4K UHD Resolution**: Generate videos at 3840x2160 resolution
- **Quality Control**: Choose between speed or quality priority
- **Custom Duration**: 5 or 10 seconds
- **Frame Rate Options**: 30 FPS or 60 FPS
- **Audio Support**: Optional AI-generated audio effects
- **Multiple Resolutions**: 4K, Full HD, HD, and landscape options

### Text to Image
- **Multiple Sizes**: Square, portrait, landscape, wide, and tall formats
- **High Quality**: Photorealistic image generation
- **Instant Results**: Fast image generation with immediate preview
- **Easy Download**: One-click download of generated images

## How to Use

### Generate 4K Video

1. **Navigate to Text to Video tab**
   - Click the "Text to Video" tab at the top

2. **Enter Your Prompt**
   - Write a detailed description of the video you want
   - Be descriptive about scenes, actions, lighting, and mood
   - Example: "A majestic eagle soaring over snow-capped mountains at golden hour, cinematic lighting, smooth camera movement"

3. **Configure Settings**
   - **Quality Mode**: Choose "Speed" for faster generation or "Quality" for better output
   - **Resolution**: Select from 4K UHD (3840x2160) down to HD
   - **Duration**: 5 or 10 seconds
   - **Frame Rate**: 30 or 60 FPS
   - **Audio**: Enable for AI-generated sound effects

4. **Generate**
   - Click "Generate 4K Video" button
   - Wait for the progress to complete
   - Video generation may take 1-3 minutes depending on settings

5. **View & Download**
   - Preview the generated video
   - Click "Download" to save it locally
   - All videos are saved in MP4 format

### Generate Realistic Image

1. **Navigate to Text to Image tab**
   - Click the "Text to Image" tab at the top

2. **Enter Your Prompt**
   - Describe the image you want in detail
   - Include style, lighting, composition, and mood
   - Example: "A professional portrait of a woman in a modern office, natural lighting, 8K resolution, photorealistic"

3. **Choose Image Size**
   - Square (1024x1024): Perfect for social media
   - Landscape (1344x768, 1152x864, 1440x720): Great for backgrounds and banners
   - Portrait (768x1344, 864x1152, 720x1440): Ideal for posters and portraits

4. **Generate**
   - Click "Generate Realistic Image" button
   - Wait a few seconds for generation
   - Image generation is typically very fast

5. **View & Download**
   - Preview the generated image
   - Click "Download" to save it locally
   - All images are saved in PNG format

## Tips for Better Results

### Video Generation

**Writing Effective Prompts:**
- Describe the scene in detail (location, time of day, weather)
- Mention camera movements (pan, zoom, tracking shot)
- Include lighting conditions (cinematic, natural, dramatic)
- Specify action and movement (slow motion, fast-paced, gentle)
- Add style descriptors (cinematic, documentary-style, artistic)

**Examples:**
- ✓ "Aerial view of tropical island paradise, drone camera slowly descending, golden hour lighting, crystal clear water, white sand beaches"
- ✓ "Abstract colorful fluid animation, smooth morphing between colors, cinematic lighting, 60 FPS, artistic style"

**Best Settings:**
- **For quick results**: Speed priority, 5 seconds, 30 FPS
- **For best quality**: Quality priority, 10 seconds, 60 FPS, with audio
- **For social media**: 1920x1080, 5 seconds, 30 FPS
- **For professional use**: 3840x2160, 10 seconds, 60 FPS, quality priority

### Image Generation

**Writing Effective Prompts:**
- Be specific about the subject (person, object, scene)
- Include art style (photorealistic, oil painting, digital art)
- Add lighting details (golden hour, studio lighting, dramatic shadows)
- Specify composition (rule of thirds, close-up, wide angle)
- Include quality terms (8K, high detail, professional)

**Examples:**
- ✓ "Professional product photography of wireless headphones on white background, studio lighting, soft shadows, ultra-detailed, 4K quality"
- ✓ "Portrait of a young woman, modern art style, vibrant colors, cityscape background, golden hour lighting"

**Size Selection:**
- **1024x1024**: Social media posts, avatars, thumbnails
- **1344x768**: Website hero images, presentation slides
- **1440x720**: YouTube thumbnails, banner images
- **768x1344**: Instagram stories, Pinterest posts, portrait photos
- **720x1440**: Mobile wallpapers, portrait posters

## Technical Details

### Video Generation
- **Resolutions Supported**:
  - 4K UHD: 3840x2160
  - Full HD: 1920x1080
  - HD Wide: 1440x720
  - Landscape: 1344x768

- **Duration Options**: 5 or 10 seconds
- **Frame Rate**: 30 or 60 FPS
- **Quality Modes**: Speed or Quality priority
- **Output Format**: MP4 video file

### Image Generation
- **Supported Sizes**:
  - Square: 1024x1024
  - Landscape: 1344x768, 1152x864, 1440x720
  - Portrait: 768x1344, 864x1152, 720x1440

- **Output Format**: PNG image file
- **Quality**: High-resolution photorealistic output

## Architecture

### Backend (Next.js API Routes)
- **Video Generation**: `/api/generate/video`
  - Uses z-ai-web-dev-sdk video generation API
  - Implements automatic polling for task completion
  - Returns direct video URL

- **Image Generation**: `/api/generate/image`
  - Uses z-ai-web-dev-sdk image generation API
  - Saves generated images to public folder
  - Returns accessible URL

### Frontend (React + shadcn/ui)
- **Tabs**: Separate interfaces for video and image generation
- **Real-time Progress**: Visual progress indicators during generation
- **History**: Track all generated content
- **Preview**: Built-in video and image preview
- **Download**: One-click download functionality

## Usage Examples

### Creating Content for Social Media

**Instagram Reel:**
```
Prompt: "A stylish fashion model walking down city street at sunset, slow motion, cinematic"
Settings: 1920x1080, 5 seconds, 30 FPS, Speed priority
```

**YouTube Thumbnail:**
```
Prompt: "Dramatic mountain landscape with storm clouds, cinematic, vibrant colors"
Settings: 1440x720 size for image
```

**TikTok Video:**
```
Prompt: "Cute cat playing with colorful toys, bright lighting, upbeat mood"
Settings: 1920x1080, 5 seconds, 60 FPS, Quality priority
```

### Professional Use Cases

**Product Video:**
```
Prompt: "Product showcase of modern smartphone, rotating 360 degrees, studio lighting, clean background"
Settings: 3840x2160, 10 seconds, 60 FPS, Quality priority
```

**Website Hero Image:**
```
Prompt: "Modern tech office with diverse team collaborating, natural lighting, professional photography style"
Settings: 1344x768 size for image
```

**Explainer Video:**
```
Prompt: "Animated infographic showing data flowing through network, smooth transitions, educational style"
Settings: 1920x1080, 10 seconds, 30 FPS, With audio
```

## Troubleshooting

### Video Generation Issues

**Issue: Generation takes too long**
- Solution: Use "Speed priority" mode or reduce duration to 5 seconds

**Issue: Video quality not as expected**
- Solution: Use "Quality priority" mode and 60 FPS

**Issue: Generation fails**
- Solution: Try a simpler prompt or reduce complexity

### Image Generation Issues

**Issue: Image doesn't match prompt**
- Solution: Make prompt more specific and descriptive

**Issue: Wrong aspect ratio**
- Solution: Select appropriate size for your use case

**Issue: Image not realistic enough**
- Solution: Add "photorealistic", "8K", "high detail" to prompt

## Best Practices

1. **Be Descriptive**: The more detail in your prompt, the better the result
2. **Experiment**: Try different settings to find what works best
3. **Iterate**: Refine prompts based on initial results
4. **Save Prompts**: Keep notes of successful prompts for reuse
5. **Check Settings**: Verify resolution and settings match your needs

## Supported File Formats

- **Videos**: MP4 (compatible with all devices and platforms)
- **Images**: PNG (lossless compression, transparency support)

## Browser Compatibility

Works on all modern browsers:
- Chrome/Edge (Chromium-based)
- Firefox
- Safari
- Mobile browsers (iOS Safari, Chrome Mobile)

## Privacy & Storage

- Generated content is stored temporarily on the server
- Download content to save permanently
- No personal data is stored or tracked
- All processing happens on secure backend servers

## Technology Stack

- **Frontend**: Next.js 15, React 19, TypeScript, Tailwind CSS, shadcn/ui
- **Backend**: Next.js API Routes, z-ai-web-dev-sdk
- **AI Models**: State-of-the-art video and image generation models

## Support

For issues or questions:
- Check browser console for error messages
- Verify network connection
- Ensure prompt is not empty
- Try reducing prompt complexity if generation fails

---

Enjoy creating stunning videos and images with AI Studio! 🚀
