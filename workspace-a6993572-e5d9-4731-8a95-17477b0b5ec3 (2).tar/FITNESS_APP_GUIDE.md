# FitTrack AI - Fitness Tracking Application

## Overview
FitTrack AI is a comprehensive fitness tracking application that provides personalized workout recommendations based on your weight, goals, and fitness level.

## Features

### 1. Fitness Profile
- **Weight Tracking**: Log and monitor your current weight
- **Personal Details**: Height, age, and activity level
- **Fitness Goals**: Choose from lose weight, build muscle, maintain weight, or improve endurance
- **Activity Levels**: Sedentary, Light, Moderate, Active, or Very Active

### 2. AI-Powered Workout Generation
- Personalized workout plans generated using AI based on your profile
- 5-6 exercises tailored to your fitness level and goals
- Each exercise includes:
  - Name and description
  - Number of sets and reps
  - Estimated duration
  - Calorie burn estimate

### 3. Daily Workout Tracking
- View your daily workout plan
- Track completion status
- See calories burned and total duration
- Mark workouts as complete

### 4. Progress Tracking
- Log your weight over time
- Add notes to each weight entry
- View complete weight history
- Track your fitness journey

### 5. Notification System
- Enable browser notifications for workout reminders
- Get daily alerts to stay on track

## How to Use

### Step 1: Create Your Profile
1. Navigate to the **Profile** tab
2. Enter your weight (kg), height (cm), and age
3. Select your activity level
4. Choose your fitness goal
5. Click **Save Profile**

### Step 2: Generate a Workout
1. Navigate to the **Workout** tab
2. Click **Generate Personalized Workout**
3. Wait for AI to create your customized plan
4. Review the exercises, sets, reps, and duration

### Step 3: Complete Your Workout
1. Go through each exercise in your plan
2. Follow the descriptions for proper form
3. Complete the specified sets and reps
4. Click **Mark Workout as Complete** when finished

### Step 4: Track Your Progress
1. Visit the **Progress** tab regularly
2. Log your current weight
3. Add notes about your progress
4. Review your weight history over time

### Step 5: Enable Notifications
1. On the **Dashboard**, click **Enable Alerts**
2. Grant browser notification permission
3. You'll receive reminders for your workouts

## Dashboard Overview

The dashboard provides:
- Current weight display
- Today's workout status (Pending/Completed)
- Notification status (Active/Disabled)
- Today's workout plan with detailed exercises

## API Endpoints

The application uses the following API routes:

- `GET/POST /api/fitness/profile` - Manage fitness profile
- `POST /api/fitness/generate-workout` - Generate AI workout plans
- `GET /api/fitness/today-workout` - Get today's workout
- `POST /api/fitness/workout/:id/complete` - Mark workout complete
- `GET/POST /api/fitness/weight-log` - Log weight entries
- `GET /api/fitness/weight-logs` - Get weight history

## Technology Stack

- **Frontend**: Next.js 15, React 19, TypeScript, Tailwind CSS, shadcn/ui
- **Backend**: Next.js API Routes, Prisma ORM
- **Database**: SQLite
- **AI Integration**: z-ai-web-dev-sdk (LLM for workout generation)
- **Notifications**: Browser Notification API

## Tips for Best Results

1. **Update Regularly**: Log your weight at least once a week
2. **Complete Workouts**: Always mark workouts as complete when done
3. **Stay Consistent**: Follow the AI-generated plans for best results
4. **Adjust Profile**: Update your profile as your fitness level improves
5. **Set Goals**: Choose realistic goals for sustainable progress

## Privacy & Data

All your fitness data is stored locally in the database. Your profile and workout history are private to your installation of the application.

## Support

For any issues or questions, refer to the project documentation or check the browser console for error messages.
